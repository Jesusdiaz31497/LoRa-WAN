This is fast SPI library for the ST7789 IPS 240x240 SPI display.

Optimized for the best performance for 16MHz AVR Arduino boards.
Requires Adafruit_GFX library for Arduino.
